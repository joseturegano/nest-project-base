export declare class PaginationDto {
    limit?: number;
    offset?: number;
}
