export declare class CommonModule {
}
