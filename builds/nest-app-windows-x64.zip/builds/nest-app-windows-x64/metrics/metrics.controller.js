"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MetricsController = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
let MetricsController = class MetricsController {
};
exports.MetricsController = MetricsController;
exports.MetricsController = MetricsController = tslib_1.__decorate([
    (0, swagger_1.ApiTags)('Metrics'),
    (0, common_1.Controller)('metrics')
], MetricsController);
//# sourceMappingURL=metrics.controller.js.map