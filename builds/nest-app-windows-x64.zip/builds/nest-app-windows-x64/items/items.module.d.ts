export declare class ItemsModule {
}
