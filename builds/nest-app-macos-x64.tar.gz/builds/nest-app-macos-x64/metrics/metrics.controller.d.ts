export declare class MetricsController {
}
