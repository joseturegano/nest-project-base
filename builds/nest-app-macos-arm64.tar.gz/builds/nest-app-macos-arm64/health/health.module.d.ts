export declare class HealthModule {
}
